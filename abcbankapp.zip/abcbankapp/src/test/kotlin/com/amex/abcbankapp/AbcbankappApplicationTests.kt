package com.amex.abcbankapp

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class AbcbankappApplicationTests {

	@Test
	fun contextLoads() {
	}

}
