package com.amex.abcbankapp

import org.springframework.boot.autoconfigure.SpringBootApplication
import org.springframework.boot.runApplication

@SpringBootApplication
class AbcbankappApplication

fun main(args: Array<String>) {
	runApplication<AbcbankappApplication>(*args)
}
