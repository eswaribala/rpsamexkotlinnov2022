rootProject.name = "customerapp"
